package application;

public class data {
	public static String username;
	public static String path;
	public static String date;
	public static Integer id;
	public static Integer cID;
}
