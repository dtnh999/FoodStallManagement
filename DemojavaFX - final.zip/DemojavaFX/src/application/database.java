package application;

import java.sql.Connection;
import java.sql.DriverManager;

public class database {
	public static Connection connectDB() {
		try {
			// Load the JDBC driver for SQL Server
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

			// Connect to the SQL Server database
			String url =  "jdbc:sqlserver://localhost;DatabaseName=FoodStall; username=sa;password=tung; encrypt=false;";
			String user = "sa";
			String password = "tung";


			Connection connect = DriverManager.getConnection(url, user, password);
			return connect;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

}